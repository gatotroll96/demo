<div class="languages_box">
    <span class="red">Languages:</span>
    <a href="#" class="selected"><img src="<?php echo $ImgUrl;?>images/gb.gif" alt="" title="" border="0" /></a>
    <a href="#"><img src="<?php echo $ImgUrl;?>images/fr.gif" alt="" title="" border="0" /></a>
    <a href="#"><img src="<?php echo $ImgUrl;?>images/de.gif" alt="" title="" border="0" /></a>
</div>
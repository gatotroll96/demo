<div class="title"><span class="title_icon"><img src="<?php echo $ImgUrl;?>images/bullet6.gif"/></span>Partners</div>                 
<ul class="list">
        <li><a href="#">accesories</a></li>
        <li><a href="#">books gifts</a></li>
        <li><a href="#">specials</a></li>
        <li><a href="#">hollidays gifts</a></li>
        <li><a href="#">accesories</a></li>
        <li><a href="#">books gifts</a></li>
        <li><a href="#">specials</a></li>
        <li><a href="#">hollidays gifts</a></li>
        <li><a href="#">accesories</a></li>                              
</ul> 
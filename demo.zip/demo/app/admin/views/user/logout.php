<?php
	echo 'heheheh';